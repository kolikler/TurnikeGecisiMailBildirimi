#pragma once
#pragma message("Deprectated: functional.h, new include name should be ustd_functional.h")
#include "ustd_functional.h"
