#pragma once
#pragma message("Deprectated: array.h, new include name should be ustd_array.h")
#include "ustd_array.h"
